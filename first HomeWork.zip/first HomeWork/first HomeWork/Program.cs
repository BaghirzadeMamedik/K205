﻿using System;

namespace Initial
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Xos gelmisiniz.");
            Evvele:
            Console.WriteLine("E-maili daxil edin: ");

            string login = Console.ReadLine();
            Console.WriteLine("Parolunuzu daxil edin: ");
            string parol = Console.ReadLine();
         
            if (login == "compar@gmail.com" && parol == "compar123")
            {
                Console.BackgroundColor = ConsoleColor.Green;
                Console.ForegroundColor = ConsoleColor.Black;

                Console.WriteLine("e-mail ve parolunuz duzgundur.");
                Console.BackgroundColor = ConsoleColor.Black;

            }
            else 
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.WriteLine("daxil etdiyiniz e-mail ve ya parol yanlishdir!!!");
               
               
                Yess:
                Console.WriteLine("Birde daxil etmek istiyirsiz?(y/n)");
                Console.BackgroundColor = ConsoleColor.Black;
                var tesdiq = Console.ReadLine();

                if (tesdiq == "y")
                {
                    Console.Clear();
                    goto Evvele;
                }
                else if (tesdiq == "n")
                {
                    Console.Clear();
                    Console.WriteLine("Sagolun");
                }
                else
                {
                    Console.Clear();
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.WriteLine("Duzgun yazin.");
                    Console.BackgroundColor = ConsoleColor.Black;
                    goto Yess;

                }

            }


           
        }
    }
}
